

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

//this is java application not maven
public class Testing {
	public static void main(String[] args) {
		// declaration and instantiation of objects/variables
		//System.setProperty("webdriver.chrome.marionette","C:\\geckodriver.exe");
		//WebDriver driver = new FirefoxDriver();
		//comment the above 2 lines and uncomment below 2 lines to use Chrome
		System.setProperty("webdriver.chrome.driver","C:\\Users\\kartikks\\Desktop\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		String baseUrl = "file:///D:/Chennai%20VnV%20batch/m4/ConferenceRegistartion.html";
		//Manage the window
		// driver.manage().window().maximize();
		driver.manage().window().setPosition(new Point(50, 50));


		String expectedTitle = "Conference Registartion";
		String actualTitle = "";
		driver.get(baseUrl);
		
		//navigations
		driver.navigate().to("https://chrome.google.com/webstore/category/extensions");
		driver.navigate().back();
		//      driver.navigate().forward();
		//      driver.navigate().back();
		//      driver.navigate().refresh();

		//		get title of website	
		actualTitle = driver.getTitle();  

		//Try with different locators
		WebElement element=driver.findElement(By.className("Format1"));//By class locator
		element.sendKeys("Kartik");
		element=driver.findElement(By.id("txtLastName"));//By Id Locator
		element.sendKeys("Kumar");
		element=driver.findElement(By.name("Email"));// By Name :Locator
		element.sendKeys("kartik@gmail.com");

		//selection drop down 
		element=driver.findElement(By.name("city"));
		Select sel = new Select(element);			// Select class & it's methods
		sel.selectByVisibleText("Pune");
		sel.selectByValue("Mumbai");
		sel.selectByIndex(0);

		
//		//Explicit Wait It must be before alert creation
//		WebDriverWait wait = new WebDriverWait(driver, 10);
//		wait.until(ExpectedConditions.alertIsPresent());
		
		//Alert Box
		//Switch the controller from Base window to alert window
		Alert alert = driver.switchTo().alert();
	System.out.println(alert.getText());
		alert.accept();//ok pressed
		//     alert.dismiss();//Esc key pressed
		



		//count no. of links 
		List<WebElement> links = driver.findElements(By.tagName("a"));// By tag-name locators
		System.out.println("No. of links: "+links.size());

		//  element=driver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));//By xpath Locators
		// element=driver.findElement(By.partialLinkText("Next"));		//   By PartialLink Locators
		element=driver.findElement(By.linkText("Next"));				//By linkText locators
		element.click();

	


		// Interrogation command
		System.out.println("Actual Title: "+driver.getTitle());
		System.out.println("Current Url: "+ driver.getCurrentUrl());
		//System.out.println("Current Url"+ driver.getPageSource());


		//Get attribute
		System.out.println("Attribute: "+driver.findElement(By.id("txtLastName")).getAttribute("type"));

		
		


		if (actualTitle.contentEquals(expectedTitle)){
			System.out.println("Test Passed!");
		} else {
			System.out.println("Test Failed");
		}
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//close Fire fox
		driver.close();

	}
}
