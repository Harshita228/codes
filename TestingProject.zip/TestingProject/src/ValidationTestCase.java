import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class ValidationTestCase {

	public static WebDriver driver;
	public static WebElement element;
	static String countEmail="";

	public static void main(String[] args) {
		boolean passed=false;
		System.setProperty("webdriver.chrome.driver","C:\\Users\\kartikks\\Desktop\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		String baseUrl = "file:///D:/Chennai%20VnV%20batch/m4/ConferenceRegistartion.html";
		//Manage the window
		driver.manage().window().maximize();
		//driver.manage().window().setPosition(new Point(50, 50));

		//Test case for title---------------------------------
		String expectedTitle = "Conference Registartion";
		String expectedFNameErrorMessage="Please fill the First Name";
		String expectedLNameErrorMessage="Please fill the Last Name";
		String expEmailBlankErrMsg ="Please fill the Email";
		String expEmailInvalidErrMsg ="Please enter valid Email Id.";
		driver.get(baseUrl);
		testTitle(expectedTitle);//test title
		//First Name error message test case
		WebElement element=driver.findElement(By.className("Format1"));//By class locator			//By linkText locators
		testFName(expectedFNameErrorMessage);
		testLName(expectedLNameErrorMessage);
		//		if(testEmail(expEmailBlankErrMsg)){
		//			testEmail(expEmailInvalidErrMsg);
		//		}
		//count no. of links 
		List<WebElement> links = driver.findElements(By.tagName("a"));// By tag-name locators
		System.out.println("No. of links: "+links.size());

		//driver.close();

	}


	public static boolean testTitle(String expTitle){
		String actualTitle="";
		boolean valid=false;
		actualTitle=driver.getTitle();
		if (actualTitle.contentEquals(expTitle)){
			System.out.println(actualTitle+"Title Test Passed!");
			return valid=true;
		} else {
			System.out.println(actualTitle+"Title Test Failed");
			return valid=false;
		}


	}


	private  static boolean testFName(String expectedFNameErrorMessage) {
		String actualErrorMsg="";
		boolean valid=false;
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		element=driver.findElement(By.linkText("Next"));				//By linkText locators
		element.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Alert Box
		//Switch the controller from Base window to alert window
		Alert alert = driver.switchTo().alert();
		actualErrorMsg=alert.getText();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (actualErrorMsg.contentEquals(expectedFNameErrorMessage)){
			System.out.println("First Name Error message: Test Passed!");
			alert.accept();//ok pressed
			return valid=true;
		} else {
			System.out.println("First Name Error message: Test Failed");
			alert.accept();//ok pressed
			return valid=false;
		}

	}

	private static boolean testLName(String expectedLNameErrorMessage) {

		String actualErrorMsg="";
		boolean valid=false;

		element=driver.findElement(By.id("txtFirstName"));
		element.sendKeys("Kartik");

		element=driver.findElement(By.linkText("Next"));				//By linkText locators
		element.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Alert Box
		//Switch the controller from Base window to alert window
		Alert alert = driver.switchTo().alert();
		actualErrorMsg=alert.getText();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (actualErrorMsg.contentEquals(expectedLNameErrorMessage)){
			System.out.println("Last Name Error message: Test Passed!");
			alert.accept();//ok pressed
			return valid=true;
		} else {
			System.out.println("Last Name Error message: Test Failed");
			alert.accept();//ok pressed
			return valid=false;
		}

	}

	private static boolean testEmail(String expEmailBlankErrMsg) {


		String actualErrorMsg="";
		boolean valid=false;
		element=driver.findElement(By.id("txtLastName"));
		element.sendKeys("Kumar");
		element=driver.findElement(By.linkText("Next"));				//By linkText locators
		element.click();
		//Alert Box
		//Switch the controller from Base window to alert window
		Alert alert = driver.switchTo().alert();
		actualErrorMsg=alert.getText();

		element=driver.findElement(By.id("txtEmail"));
		element.sendKeys(countEmail);
		String emailTxt=element.getText();
		if( emailTxt.equals("")){
			if (actualErrorMsg.contentEquals(expEmailBlankErrMsg)){
				System.out.println("Email Blank Error message: Test Passed!");
				alert.accept();//ok pressed
				countEmail="kar";
				return valid=true;
			} else {
				System.out.println("Email Blank Error message: Test Failed");
				alert.accept();//ok pressed
				countEmail="kar";
				return valid=false;
			}

		}
		else if(!emailTxt.equals(""))
		{
			if (actualErrorMsg.contentEquals(expEmailBlankErrMsg)){
				System.out.println("Email Invalid Error message: Test Passed!");
				alert.accept();//ok pressed
				return valid=true;
			} else {
				System.out.println("Email Invalid Error message: Test Failed");
				alert.accept();//ok pressed
				return valid=false;
			}
		}
		else
			return false;
	}




}
